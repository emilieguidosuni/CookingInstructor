﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cooking_Instructor
{
    /// <summary>
    /// Interaction logic for RecipeBlock.xaml
    /// </summary>
    public partial class RecipeBlock : UserControl
    {
        public RecipeBlock()
        {
            InitializeComponent();
        }

        public RecipeBlock(string imageName)
        {
            InitializeComponent();
            this.ImageText.Text = imageName;
            string photoName = imageName + ".jpg";

            Uri uri = new Uri(photoName, UriKind.RelativeOrAbsolute);
            BitmapImage bitmap = new BitmapImage(uri);
            Image img = new Image();

            this.ImageOfPhoto.Source = bitmap;
        }
    }
}
