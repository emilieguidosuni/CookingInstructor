﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cooking_Instructor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // List(Array) of all the screens
        Grid[] listOfScreens;
        // Previous screen to go back onclick "Back"
        //Grid previousScreen;
        Grid previousFooter;
        Grid currentScreen;

        Grid currentRecipe;

        // CheckedBoxes
        //List<String> checkedBoxes;
        List<CheckBox> checkedBoxesIngredients;
        List<CheckBox> checkedBoxesCookware;

        //Stack to keep track of previous pages
        public Stack<Grid> pageStack = new Stack<Grid>();



        public MainWindow()
        {
            InitializeComponent();
            listOfScreens = new Grid[] {
                HomePage, RecipesPage, GlossaryPage,
                MainFooterGrid,SingleStepPage1,SingleStepLastPage,
                TechniqueStepByStepPage,
                RecipeMainPage, TechniqueVideo, TechniquesForRecipePage
            };

            //checkedBoxes = new List<String>();
            checkedBoxesIngredients = new List<CheckBox>();
            checkedBoxesCookware = new List<CheckBox>();

            // Bring up the homepage
            BringFront(HomePage, MainFooterGrid);
            currentScreen = HomePage;

            pageStack.Push(HomePage);

            string[] recipeListNames = System.IO.File.ReadAllLines("RecipeList.txt");
            foreach (string recipeName in recipeListNames)
            {
                RecipeBlock thumbnail = new RecipeBlock(recipeName);
                thumbnail.MouseLeftButtonDown += OnThumbnailClicked;
                thumbnail.MouseEnter += Pasta_MouseEnter;
                thumbnail.MouseLeave += Pasta_MouseLeave;
                this.RecipeGrid.Children.Add(thumbnail);
            }


        }




        /// <summary>
        ///     This function hides all the screens except the 
        ///     one that is sent in as a parameter, and brings 
        ///     that to the front. Pushes that screen to the 
        ///     top of the pageStack. Also has an option to bring 
        ///     a footer to front as well.
        /// </summary>
        /// <param name="screen"> Screen to bring front </param>
        /// <param name="footer"> Footer to bring front </param>
        public void BringFront(Grid screen, Grid footer)
        {
            foreach (Grid g in listOfScreens)
            {
                if (g != screen) // || g != footer)
                {
                    g.Visibility = Visibility.Collapsed;
                }

            }

            // Set the screen
            screen.Visibility = Visibility.Visible;

            //push the screen to the top of the page stack
            pageStack.Push(screen);

            // Set the footer
            if (footer != null)
            {
                footer.Visibility = Visibility.Visible;

                if (footer == MainFooterGrid)
                {
                    //Set which tabs should be highlighted
                    if (screen == RecipesPage)
                    {
                        HomeTab.Visibility = Visibility.Visible;
                        HomeTab2.Visibility = Visibility.Hidden;

                        GlossaryTab.Visibility = Visibility.Visible;
                        GlossaryTab2.Visibility = Visibility.Hidden;

                        RecipeTab.Visibility = Visibility.Hidden;
                        RecipeTab2.Visibility = Visibility.Visible;
                    }
                    else if (screen == GlossaryPage)
                    {
                        HomeTab.Visibility = Visibility.Visible;
                        HomeTab2.Visibility = Visibility.Hidden;

                        GlossaryTab.Visibility = Visibility.Hidden;
                        GlossaryTab2.Visibility = Visibility.Visible;

                        RecipeTab.Visibility = Visibility.Visible;
                        RecipeTab2.Visibility = Visibility.Hidden;
                    }

                    else if (screen == HomePage)
                    {
                        HomeTab.Visibility = Visibility.Hidden;
                        HomeTab2.Visibility = Visibility.Visible;

                        GlossaryTab.Visibility = Visibility.Visible;
                        GlossaryTab2.Visibility = Visibility.Hidden;

                        RecipeTab.Visibility = Visibility.Visible;
                        RecipeTab2.Visibility = Visibility.Hidden;
                    }
                }
          
            }

        }
        


        



        // allows the screen to be moved around
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);

            // Begin dragging the window
            this.DragMove();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape) {
                Close();
            }
        }

        private void Window_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
            }
        }


        private void GeneralSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            SettingsPage.Visibility = Visibility.Visible;
            
        }


        // ... usercontrol settings


        // Settings hoverover
        private void SettingsButtonControl_MouseEnter(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Hand;
        }

        private void SettingsButtonControl_MouseLeave(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Arrow;
        }

        


        ///////////////////////////////



       

        private void RecipesButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //Remove top of stack and set this as the first screen
            BringFront(RecipesPage, MainFooterGrid);
            //currentScreen = RecipesPage;

        }

        private void HomeButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //Remove top of stack and set this as the first screen
            BringFront(HomePage, MainFooterGrid);
            //currentScreen = HomePage;
        }

        private void GlossaryButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //Remove top of stack and set this as the first screen
            BringFront(GlossaryPage, MainFooterGrid);
            //currentScreen = GlossaryPage;
        }

        private void NextStepButton1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            BringFront(SingleStepLastPage, null);
           // previousScreen = currentScreen;
            //currentScreen = SingleStepLastPage;
        }

        private void PreviousStepButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //remove current screen from stack
            Grid previous = pageStack.Pop(); //get previous screen
            BringFront(previous, null); //previous screen is pushed back onto stack in BringFront()

            //currentScreen.Visibility = Visibility.Hidden;
            //previousScreen.Visibility = Visibility.Visible;
            //currentScreen = previousScreen;
        }

        private void PreviousStepButtonControl_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //remove current screen from stack
            Grid previous = pageStack.Pop(); //get previous screen
            BringFront(previous, null); //previous screen is pushed back onto stack in B
        }

        //*************************************NEEDS MODIFYING
        private void FinishButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            while(pageStack.Peek() != currentRecipe)
            {
                pageStack.Pop();
            }
            pageStack.Pop(); //pop recipe page
            BringFront(currentRecipe, null);
            //currentScreen.Visibility = Visibility.Hidden;
            //RecipeMainPage_Pasta.Visibility = Visibility.Visible;
           
            //RecipeMainPage.Visibility = Visibility.Visible;
           // currentScreen = RecipeMainPage;
        }
        
        private void BackToRecipeButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {

            while (pageStack.Peek() != currentRecipe)
            {
                pageStack.Pop();
            }
            pageStack.Pop(); //pop recipe page
            BringFront(currentRecipe, null); ;
            // currentScreen.Visibility = Visibility.Hidden;
            //RecipePages.Visibility = Visibility.Visible;
            // currentScreen = RecipePages;
        }
        //***************************************


        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
        }


        ////////////////////////////////////////////////////////////////

        private void RecipeIngredients_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            TreeViewItem item = sender as TreeViewItem;
            if (item.IsExpanded)
            {
                item.IsExpanded = false;
            }
            else
            {
                item.IsExpanded = true;
            }
            if (item.IsSelected)
            {
                e.Handled = true;

            }


        }

        private void CheckBox_Checked_Ingredients(object sender, RoutedEventArgs e)
        {
            IngredientsChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = true;

        }


        private void CheckBox_Unchecked_Ingredients(object sender, RoutedEventArgs e)
        {
            IngredientsChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = false;
        }

        private void CheckBox_Checked_Cookware(object sender, RoutedEventArgs e)
        {
            CookwareChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = true;

        }


        private void CheckBox_Unchecked_Cookware(object sender, RoutedEventArgs e)
        {
            CookwareChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = false;
        }

        private void IngredientsChecked(CheckBox checkBox)
        {
            // Use IsChecked.
            bool flag = checkBox.IsChecked.Value;

            if (flag == true)
            {
                //if (!checkedBoxes.Contains(cb))
                {
                    checkedBoxesIngredients.Add(checkBox);
                }
            }
            else
            {

                checkedBoxesIngredients.Remove(checkBox);
            }
        }

        private void CookwareChecked(CheckBox checkBox)
        {
            // Use IsChecked.
            bool flag = checkBox.IsChecked.Value;

            if (flag == true)
            {
                //if (!checkedBoxes.Contains(cb))
                {
                    checkedBoxesCookware.Add(checkBox);
                }
            }
            else
            {

                checkedBoxesCookware.Remove(checkBox);
            }
        }

        void HandleCheckBox(CheckBox checkBox)
        {
            // Check if all the checboxes are checkedy checked
            //if (checkedBoxes.Contains("AllIngredientsCheckbox") &&
            //   checkedBoxes.Contains("AllCookwareCheckbox"))
            if ((checkedBoxesIngredients.Contains(AllIngredientsCheckbox))
               && (checkedBoxesCookware.Contains(AllCookwareCheckbox)))
            {
                StartButton4.Opacity = 100;
                StartButton4.IsEnabled = true;
            }
            else
            {
                StartButton4.Opacity = 0.5;
                StartButton4.IsEnabled = false;
            }


        }

        private void StartButton_MouseDown(object sender, MouseButtonEventArgs e)
        {            
           //previousScreen = RecipeMainPage_Pasta;
            //previousFooter = null;
            BringFront(SingleStepPage1, null);
          
           // currentScreen = SingleStepPage1;
        }

        //
        private void RecipeSteps_Click(object sender, RoutedEventArgs e)
        {
           // RecipeStepsScreen.Visibility = Visibility.Visible;
           // RecipeMainPage.Visibility = Visibility.Hidden;
        }

        //
        private void RecipeInformation1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           // RecipeStepsScreen.Visibility = Visibility.Visible;
        }


        private void BackButton_RecipeMain_Click(object sender, RoutedEventArgs e)
        {
            //RecipeMainPage_Pasta.Visibility = Visibility.Hidden;
            pageStack.Pop();
            BringFront(RecipesPage, MainFooterGrid);
        }

        private void Pasta_Click(object sender, RoutedEventArgs e)
        {
            BringFront(RecipeMainPage, null);
            currentRecipe = RecipeMainPage;
        }

        private void Pasta_MouseEnter(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Hand;
        }

        private void Pasta_MouseLeave(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Arrow;
        }

        private void MainRecipe_Steps_Button_Click(object sender, RoutedEventArgs e)
        {
            RecipeSteps_Main.Visibility = Visibility.Visible;
        }

        private void BackButton_Setting_Click(object sender, RoutedEventArgs e)
        {
            Grid previous = pageStack.Pop();
            BringFront(previous, previousFooter);
            //currentScreen = previousScreen;
        }






        //////////


        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
            
        }

        private void ViewStepByStepButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
        }

        private void BackButtonControl_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop();
            Grid previous = pageStack.Pop();
            BringFront(previous, null);
            //currentScreen = previousScreen;
            //BringFront(previousScreen, null);
            //previousScreen = TechniqueStepByStepPage;
        }

        private void WatchVideoButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
        }


        private void TextBlock_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
        }

        private void StartButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            BringFront(SingleStepPage1, null);
        }

        private void IngredientsTabControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            IngredientsListScroller.Visibility = Visibility.Visible; //Show ingredients checklist, hide others
            CookwareListScroller.Visibility = Visibility.Hidden;
            RecipeStepsScroller.Visibility = Visibility.Hidden;

            IngredientsTab1.Visibility = Visibility.Hidden;
            IngredientsTab2.Visibility = Visibility.Visible;

            CookwareTab1.Visibility = Visibility.Visible;
            CookwareTab2.Visibility = Visibility.Hidden;

            StepsTab1.Visibility = Visibility.Visible;
            StepsTab2.Visibility = Visibility.Hidden;

        }

        private void CookwareTab1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            IngredientsListScroller.Visibility = Visibility.Hidden; 
            CookwareListScroller.Visibility = Visibility.Visible; // Show cookware checklist, hide others
            RecipeStepsScroller.Visibility = Visibility.Hidden;

            IngredientsTab1.Visibility = Visibility.Visible;
            IngredientsTab2.Visibility = Visibility.Hidden;

            CookwareTab1.Visibility = Visibility.Hidden;
            CookwareTab2.Visibility = Visibility.Visible;

            StepsTab1.Visibility = Visibility.Visible;
            StepsTab2.Visibility = Visibility.Hidden;
        }

        private void StepsTab1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            IngredientsListScroller.Visibility = Visibility.Hidden; 
            CookwareListScroller.Visibility = Visibility.Hidden;
            RecipeStepsScroller.Visibility = Visibility.Visible; //Show recipe steps scroller and hide others

            IngredientsTab1.Visibility = Visibility.Visible;
            IngredientsTab2.Visibility = Visibility.Hidden;

            CookwareTab1.Visibility = Visibility.Visible;
            CookwareTab2.Visibility = Visibility.Hidden;

            StepsTab1.Visibility = Visibility.Hidden;
            StepsTab2.Visibility = Visibility.Visible;
        }

        private void StartButton_RecipePage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            BringFront(TechniquesForRecipePage, null);
        }

        private void OnThumbnailClicked(object sender, MouseButtonEventArgs e)
        {
            BringFront(RecipeMainPage, null);
            currentRecipe = RecipeMainPage;
            this.PageTitle_RecipeMain.Text = (sender as RecipeBlock).ImageText.Text;
            this.RecipeImage_Main.Source = (sender as RecipeBlock).ImageOfPhoto.Source;

            string recipeName = (sender as RecipeBlock).ImageText.Text;
            string recipeName1 = "Recipes\\" + recipeName.Replace(' ', '-') + ".txt";

            string[] recipeInstructions = System.IO.File.ReadAllLines(recipeName1);
            foreach (string recipeLine in recipeInstructions)
            {
                System.Diagnostics.Debug.WriteLine(recipeLine);
               
            }

        }
    }
}
