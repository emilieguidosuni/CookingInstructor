﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cooking_Instructor
{
    /// <summary>
    /// Interaction logic for ViewTechniquePageControl.xaml
    /// </summary>
    public partial class ViewTechniquePageControl : UserControl
    {
        public ViewTechniquePageControl()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Collapsed;
        }

        private void SettingsButtonControl_MouseEnter(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Hand;
        }

        private void SettingsButtonControl_MouseLeave(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Arrow;
        }

        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
        }

        private void ViewStepByStepButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            TechniqueStepByStepPage.Visibility = Visibility.Visible;
        }

        private void WatchVideoButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            TechniqueVideo.Visibility = Visibility.Visible;
        }


        private void TextBlock_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
        }

        private void BackButtonControl_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
            TechniqueVideo.Visibility = Visibility.Collapsed;
            TechniqueStepByStepPage.Visibility = Visibility.Collapsed;

        }

               
    }
}
