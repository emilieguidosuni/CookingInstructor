﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cooking_Instructor
{
    /// <summary>
    /// Interaction logic for SettingsPageControl.xaml
    /// </summary>
    public partial class SettingsPageControl : UserControl
    {


        // Settings Option - Binary
        private StringBuilder settingsEnabled;

        public SettingsPageControl()
        {
            InitializeComponent();
            settingsEnabled = new StringBuilder("000");
        }

        public string appSettings
        {
            get { return settingsEnabled.ToString(); }
        }

        private void SettingsButtonControl_MouseEnter(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Hand;
        }

        private void SettingsButtonControl_MouseLeave(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Arrow;
        }

        private void BackButton_Setting_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Collapsed;
        }


        // SKIP CHECKLIST
        private void checkboxSkipChecklist_Checked(object sender, RoutedEventArgs e)
        {
            settingsEnabled[0] = '1';
        } 

        private void checkboxSkipChecklist_Unchecked(object sender, RoutedEventArgs e)
        {
            settingsEnabled[0] = '0';
        }

        // SKIP TERMS
        private void checkboxSkipTerms_Checked(object sender, RoutedEventArgs e)
        {
            settingsEnabled[1] = '1';
        }

        private void checkboxSkipTerms_Unchecked(object sender, RoutedEventArgs e)
        {
            settingsEnabled[1] = '0';
        }

        // AUTO START
        private void checkboxAutoStart_Checked(object sender, RoutedEventArgs e)
        {
            settingsEnabled[2] = '1';
        }

        private void checkboxAutoStart_Unchecked(object sender, RoutedEventArgs e)
        {
            settingsEnabled[2] = '0';
        }
    }
}
