﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cooking_Instructor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // List(Array) of all the screens
        Grid[] listOfScreens;
        // Previous screen to go back onclick "Back"
        //Grid previousScreen;
        Grid previousFooter;
        Grid currentScreen;

        Grid currentRecipe;

        // RecipeDatabase
        List<string> RecipeDatabase;

        // GlossaryDatabase
        List<string> GlossaryDatabase;

        // Settings Option - Binary
        string settingsEnabled;


        // CheckedBoxes
        //List<String> checkedBoxes;
        List<CheckBox> checkedBoxesIngredients;
        List<CheckBox> checkedBoxesCookware;
        List<CheckBox> AllIngredientBoxes;
        List<CheckBox> AllCookwareBoxes;

        //Stack to keep track of previous pages
        public Stack<Grid> pageStack = new Stack<Grid>();

        //Recipe Information Lists
        List<string> IngredientsList;
        List<string> CookwareList;
        List<string> StepsList;
        List<string> TechniqueList;
        string difficulty;
        string cookTime;
        int currentStep = 0;
        int totalSteps = 0;
        int totalTechniques = 0;
        string currentRecipeName;
        int techniqueForStep;

        //Keeps track of current term
        string currentTerm = null;

        public MainWindow()
        {
            InitializeComponent();

            //SettingsPageControl
            listOfScreens = new Grid[] {
                HomePage, RecipesPage, GlossaryPage,
                MainFooterGrid,SingleStepPage1,SingleStepLastPage,
                TechniqueStepByStepPage, ViewTechniquePage, ViewTermPage,
                RecipeMainPage, TechniqueVideo, TechniquesForRecipePage
            };

            // Create the database lists
            RecipeDatabase = new List<string>();
            GlossaryDatabase = new List<string>();

            //checkedBoxes = new List<String>();
            checkedBoxesIngredients = new List<CheckBox>();
            checkedBoxesCookware = new List<CheckBox>();
            AllIngredientBoxes = new List<CheckBox>();
            AllCookwareBoxes = new List<CheckBox>();

            // Bring up the homepage
            BringFront(HomePage, MainFooterGrid);
            currentScreen = HomePage;

            pageStack.Push(HomePage);

            // Load up the Recipes
            string[] recipeListNames = System.IO.File.ReadAllLines("RecipeList.txt");
            foreach (string recipeName in recipeListNames)
            {
                // Add recipes to the database list
                RecipeDatabase.Add(recipeName);

                RecipeBlock thumbnail = new RecipeBlock(recipeName);
                thumbnail.MouseLeftButtonDown += OnThumbnailClicked;
                thumbnail.MouseEnter += Pasta_MouseEnter;
                thumbnail.MouseLeave += Pasta_MouseLeave;
                this.RecipeGrid.Children.Add(thumbnail);
            }

            IngredientsList = new List<string>();
            CookwareList = new List<string>();
            StepsList = new List<string>();
            TechniqueList = new List<string>();


            //Load up the Glossary
            string[] techniqueListNames = System.IO.File.ReadAllLines("TechniqueList.txt");
            foreach (string techniqueName in techniqueListNames)
            {
                // Add recipes to the database list
                GlossaryDatabase.Add(techniqueName);

                GlossaryEntry newTerm = new GlossaryEntry(techniqueName);
                newTerm.MouseLeftButtonDown += OnTermClicked;
                newTerm.MouseEnter += Pasta_MouseEnter;
                newTerm.MouseLeave += Pasta_MouseLeave;
                this.GlossaryGrid.Children.Add(newTerm);
            }

            // Get the settings (initially all disabled)
            settingsEnabled = "000";

        }

        public void updateSettings()
        {
            // Update the latest settings
            settingsEnabled = SettingsPage.appSettings;

            // If setting #1 is enabled, skip checklists
            // -> Start always visible
            if (settingsEnabled[0] == '1')
            {
                StartButton4.Opacity = 0.5;
                //StartButton4.IsEnabled = true;
            }

            // implemented inline until changes
            if (settingsEnabled[0] == '1')
            {

            }

            // implemented inline until changes
            if (settingsEnabled[0] == '1')
            {

            }


        }


        /// <summary>
        ///     This function hides all the screens except the 
        ///     one that is sent in as a parameter, and brings 
        ///     that to the front. Pushes that screen to the 
        ///     top of the pageStack. Also has an option to bring 
        ///     a footer to front as well.
        /// </summary>
        /// <param name="screen"> Screen to bring front </param>
        /// <param name="footer"> Footer to bring front </param>
        public void BringFront(Grid screen, Grid footer)
        {
            foreach (Grid g in listOfScreens)
            {
                if (g != screen) // || g != footer)
                {
                    g.Visibility = Visibility.Collapsed;
                }

            }

            // Set the screen
            screen.Visibility = Visibility.Visible;

            //push the screen to the top of the page stack
            pageStack.Push(screen);

            // Set the footer
            if (footer != null)
            {
                footer.Visibility = Visibility.Visible;

                if (footer == MainFooterGrid)
                {
                    //Set which tabs should be highlighted
                    if (screen == RecipesPage)
                    {
                        HomeTab.Visibility = Visibility.Visible;
                        HomeTab2.Visibility = Visibility.Hidden;

                        GlossaryTab.Visibility = Visibility.Visible;
                        GlossaryTab2.Visibility = Visibility.Hidden;

                        RecipeTab.Visibility = Visibility.Hidden;
                        RecipeTab2.Visibility = Visibility.Visible;
                    }
                    else if (screen == GlossaryPage)
                    {
                        HomeTab.Visibility = Visibility.Visible;
                        HomeTab2.Visibility = Visibility.Hidden;

                        GlossaryTab.Visibility = Visibility.Hidden;
                        GlossaryTab2.Visibility = Visibility.Visible;

                        RecipeTab.Visibility = Visibility.Visible;
                        RecipeTab2.Visibility = Visibility.Hidden;
                    }

                    else if (screen == HomePage)
                    {
                        HomeTab.Visibility = Visibility.Hidden;
                        HomeTab2.Visibility = Visibility.Visible;

                        GlossaryTab.Visibility = Visibility.Visible;
                        GlossaryTab2.Visibility = Visibility.Hidden;

                        RecipeTab.Visibility = Visibility.Visible;
                        RecipeTab2.Visibility = Visibility.Hidden;
                    }
                }

            }

        }







        // allows the screen to be moved around
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);

            // Begin dragging the window
            this.DragMove();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
            }
        }

        private void Window_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
            }
        }


        private void GeneralSettingsButton_Click(object sender, RoutedEventArgs e)
        {
            SettingsPage.Visibility = Visibility.Visible;

        }


        // ... usercontrol settings


        // Settings hoverover
        private void SettingsButtonControl_MouseEnter(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Hand;
        }

        private void SettingsButtonControl_MouseLeave(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Arrow;
        }




        ///////////////////////////////





        private void RecipesButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //Remove top of stack and set this as the first screen
            BringFront(RecipesPage, MainFooterGrid);
            //currentScreen = RecipesPage;

        }

        private void HomeButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //Remove top of stack and set this as the first screen
            BringFront(HomePage, MainFooterGrid);
            //currentScreen = HomePage;
        }

        private void GlossaryButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop(); //Remove top of stack and set this as the first screen
            BringFront(GlossaryPage, MainFooterGrid);
            //currentScreen = GlossaryPage;
        }

        private void NextStepButton1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            currentStep++;
            if (currentStep == totalSteps)
            {
                UpdateLastStepPage();
                BringFront(SingleStepLastPage, null);
            }
            else
            {
                UpdateSingleStepPage();
            }

        }

        /// <summary>
        /// Mouse down event for Prev.Step button on FINAL STEP PAGE
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PreviousStepButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            currentStep--;
            UpdateSingleStepPage();
            BringFront(SingleStepPage1, null);

        }

        private void PreviousStepButtonControl_MouseDown_1(object sender, MouseButtonEventArgs e)
        {

            if (currentStep == 1)
            {
                currentStep = 0;
                pageStack.Pop(); //remove current screen from stack
                Grid previous = pageStack.Pop(); //get previous screen
                BringFront(previous, null); //previous screen is pushed back onto stack in BringFront()
            }
            else
            {
                currentStep--;
                UpdateSingleStepPage();
            }
        }

        //*************************************NEEDS MODIFYING
        private void FinishButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            while (pageStack.Peek() != currentRecipe)
            {
                pageStack.Pop();
            }
            pageStack.Pop(); //pop recipe page
            BringFront(currentRecipe, null);
            //currentScreen.Visibility = Visibility.Hidden;
            //RecipeMainPage_Pasta.Visibility = Visibility.Visible;

            //RecipeMainPage.Visibility = Visibility.Visible;
            // currentScreen = RecipeMainPage;
        }

        private void BackToRecipeButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // ------------------> MIGHT MESS THINGS UP
            if (settingsEnabled[1] == '1')
            {
                BringFront(currentRecipe, null);
            }
            else if (settingsEnabled[2] == '1')
            {
                BringFront(RecipesPage, null);
            }
            else
            {
                while (pageStack.Peek() != currentRecipe)
                {
                    pageStack.Pop();
                }
                pageStack.Pop(); //pop recipe page
                BringFront(currentRecipe, null);
                // currentScreen.Visibility = Visibility.Hidden;
                //RecipePages.Visibility = Visibility.Visible;
                // currentScreen = RecipePages;
            }


        }
        //***************************************


        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GetNameOfTerm();
            ViewTechniquePage.Visibility = Visibility.Visible;
        }


        ////////////////////////////////////////////////////////////////

        private void RecipeIngredients_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            TreeViewItem item = sender as TreeViewItem;
            if (item.IsExpanded)
            {
                item.IsExpanded = false;
            }
            else
            {
                item.IsExpanded = true;
            }
            if (item.IsSelected)
            {
                e.Handled = true;

            }


        }

        private void CheckBox_Checked_Ingredients(object sender, RoutedEventArgs e)
        {
            IngredientsChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = true;

        }


        private void CheckBox_Unchecked_Ingredients(object sender, RoutedEventArgs e)
        {
            IngredientsChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = false;
        }

        private void CheckBox_Checked_Cookware(object sender, RoutedEventArgs e)
        {
            CookwareChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = true;

        }


        private void CheckBox_Unchecked_Cookware(object sender, RoutedEventArgs e)
        {
            CookwareChecked(sender as CheckBox);
            HandleCheckBox(sender as CheckBox);
            e.Handled = false;
        }

        private void IngredientsChecked(CheckBox checkBox)
        {
            // Use IsChecked.
            bool flag = checkBox.IsChecked.Value;

            if (checkBox == AllIngredientsCheckbox)
            {
                SelectAllIngredientsChecked();
            }
            else
            {
                if (flag == true)
                {
                    {
                        checkedBoxesIngredients.Add(checkBox);
                    }
                }
                else
                {
                    checkedBoxesIngredients.Remove(checkBox);
                    //checkedBoxesIngredients.Remove(AllIngredientsCheckbox);
                    //AllIngredientsCheckbox.IsChecked = false;

                }
            }
        }

        /// <summary>
        /// What happens when the Select All box is checked on the ingredients page
        /// </summary>
        private void SelectAllIngredientsChecked()
        {
            bool flag = AllIngredientsCheckbox.IsChecked.Value;
            if (flag == true)       //if Select All is checked, check all remaining unchecked boxes
            {
                foreach (CheckBox cb in AllIngredientBoxes)
                {
                    if (!(cb.IsChecked.Value))
                    {
                        cb.IsChecked = true;
                        checkedBoxesIngredients.Add(cb);
                    }
                }
                checkedBoxesIngredients.Add(AllIngredientsCheckbox);
                AllIngredientsCheckbox.Content = "Deselect All";
            }
            else//if select all is unchecked, uncheck all boxes
            {
                foreach (CheckBox cb in AllIngredientBoxes)
                {
                    cb.IsChecked = false;
                    checkedBoxesIngredients.Remove(cb);
                }
                checkedBoxesIngredients.Remove(AllIngredientsCheckbox);
                AllIngredientsCheckbox.Content = "Select All";
            }

        }

        private void CookwareChecked(CheckBox checkBox)
        {
            // Use IsChecked.
            bool flag = checkBox.IsChecked.Value;

            if (checkBox == AllCookwareCheckbox)
            {
                SelectAllCookwareChecked();
            }

            else
            {
                if (flag == true)
                {
                    //if (!checkedBoxes.Contains(cb))
                    {
                        checkedBoxesCookware.Add(checkBox);
                    }
                }
                else
                {

                    checkedBoxesCookware.Remove(checkBox);
                }
            }
        }

        /// <summary>
        /// What happens when the Select All box is checked on the cookware page
        /// </summary>
        private void SelectAllCookwareChecked()
        {
            bool flag = AllCookwareCheckbox.IsChecked.Value;
            if (flag == true)       //if Select All is checked, check all remaining uncheck
            {
                foreach (CheckBox cb in AllCookwareBoxes)
                {
                    if (!(cb.IsChecked.Value))
                    {
                        cb.IsChecked = true;
                        checkedBoxesCookware.Add(cb);
                    }
                }
                checkedBoxesCookware.Add(AllCookwareCheckbox);
                AllCookwareCheckbox.Content = "Deselect All";
            }
            else//if select all is unchecked, uncheck all boxes
            {
                foreach (CheckBox cb in AllCookwareBoxes)
                {
                    cb.IsChecked = false;
                    checkedBoxesCookware.Remove(cb);
                }
                checkedBoxesCookware.Remove(AllCookwareCheckbox);
                AllCookwareCheckbox.Content = "Select All";
            }

        }

        void HandleCheckBox(CheckBox checkBox)
        {
            // Check if all the checboxes are checkedy checked
            //if (checkedBoxes.Contains("AllIngredientsCheckbox") &&
            //   checkedBoxes.Contains("AllCookwareCheckbox"))

            // if settings #1 is enabled, keep start enabled
            if (settingsEnabled[0] == '1')
            {
                return;
            }
            else if (VerifyAllBoxesChecked())
            {
                StartButton4.Opacity = 100;
                ReminderBox.Visibility = Visibility.Hidden;
                //StartButton4.IsEnabled = true;
            }
            else
            {
                StartButton4.Opacity = 0.5;
                //StartButton4.IsEnabled = false;
            }


        }

        /// <summary>
        /// Verifies that all ingredients and cookware have been checked off
        /// Returns false if a single ingredient or cookware is missing
        /// </summary>
        /// <returns></returns>
        private bool VerifyAllBoxesChecked()
        {
            foreach (CheckBox ing in AllIngredientBoxes)
            {
                if (!checkedBoxesIngredients.Contains(ing))
                {
                    return false;
                }
            }
            foreach (CheckBox cw in AllCookwareBoxes)
            {
                if (!checkedBoxesCookware.Contains(cw))
                {
                    return false;
                }
            }
            return true;
        }

        private void StartButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //previousScreen = RecipeMainPage_Pasta;
            //previousFooter = null;
            BringFront(SingleStepPage1, null);

            // currentScreen = SingleStepPage1;
        }

        //
        private void RecipeSteps_Click(object sender, RoutedEventArgs e)
        {
            // RecipeStepsScreen.Visibility = Visibility.Visible;
            // RecipeMainPage.Visibility = Visibility.Hidden;
        }

        //
        private void RecipeInformation1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // RecipeStepsScreen.Visibility = Visibility.Visible;
        }


        private void BackButton_RecipeMain_Click(object sender, RoutedEventArgs e)
        {
            //RecipeMainPage_Pasta.Visibility = Visibility.Hidden;
            pageStack.Pop();
            BringFront(RecipesPage, MainFooterGrid);
        }

        private void Pasta_Click(object sender, RoutedEventArgs e)
        {
            BringFront(RecipeMainPage, null);
            currentRecipe = RecipeMainPage;
        }

        private void Pasta_MouseEnter(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Hand;
        }

        private void Pasta_MouseLeave(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Arrow;
        }

        private void MainRecipe_Steps_Button_Click(object sender, RoutedEventArgs e)
        {
            RecipeSteps_Main.Visibility = Visibility.Visible;
        }

        private void BackButton_Setting_Click(object sender, RoutedEventArgs e)
        {
            Grid previous = pageStack.Pop();
            BringFront(previous, previousFooter);
            //currentScreen = previousScreen;
        }






        //////////


        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;

        }

        private void ViewStepByStepButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            TechStepByStep.Children.Clear();
            BringFront(TechniqueStepByStepPage, null);
            this.TechniqueTitle2.Text = currentTerm;
            string nameTerm = "Terms\\" + currentTerm.Replace(" ", "-") + ".txt";
            string[] termContents = System.IO.File.ReadAllLines(nameTerm);
            Boolean readSteps = false;
            int i = 0;
            int stepNumber = 0;
            foreach (string line in termContents)
            {
                if (readSteps == true)
                {
                    i = i + 1;
                    string imageStepName = "Terms\\" + currentTerm.Replace(" ", "-") + "\\Step" + i + ".jpg";

                    Uri uri = new Uri(imageStepName, UriKind.RelativeOrAbsolute);
                    BitmapImage bitmap = new BitmapImage(uri);
                    Image img = new Image();
                    img.Source = bitmap;
                    TechStepByStep.Children.Add(img);

                    TextBlock newStep = new TextBlock();
                    newStep.Text = line;
                    newStep.TextWrapping = TextWrapping.Wrap;
                    var bc = new BrushConverter();
                    newStep.Foreground = (Brush)bc.ConvertFrom("#FF59A47D");
                    TechStepByStep.Children.Add(newStep);
                    TextBlock newSpace = new TextBlock();
                    TechStepByStep.Children.Add(newSpace);
                    if (i == stepNumber)
                    {
                        readSteps = false;
                    }
                }

                if (line.Contains("Steps:"))
                {
                    string[] line1 = line.Split(':');
                    stepNumber = Int32.Parse(line1[1]);
                    readSteps = true;
                }
            }
        }

        private void BackButtonControl_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop();
            Grid previous = pageStack.Pop();
            BringFront(previous, null);
            //currentScreen = previousScreen;
            //BringFront(previousScreen, null);
            //previousScreen = TechniqueStepByStepPage;
        }

        private void WatchVideoButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            BringFront(TechniqueVideo, null);
            this.TechniqueTitle1.Text = currentTerm;
            string currentTermPic = "Terms\\" + currentTerm.Replace(" ", "-") + ".jpg";
            Uri uri = new Uri(currentTermPic, UriKind.RelativeOrAbsolute);
            BitmapImage bitmap = new BitmapImage(uri);
            Image img = new Image();
            this.VideoOfTechnique.Source = bitmap;
        }


        private void TextBlock_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            ViewTechniquePage.Visibility = Visibility.Visible;
        }

        private void StartButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!VerifyAllBoxesChecked())
            {
                ReminderBox.Visibility = Visibility.Visible;
            }
            else
            {
                currentStep = 1;
                UpdateSingleStepPage();
                PageTitle_Recipes1.Text = currentRecipeName;
                PageTitle_Recipes2.Text = currentRecipeName;
                BringFront(SingleStepPage1, null);
            }
        }

        private void IngredientsTabControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            IngredientsListScroller.Visibility = Visibility.Visible; //Show ingredients checklist, hide others
            CookwareListScroller.Visibility = Visibility.Hidden;
            RecipeStepsScroller.Visibility = Visibility.Hidden;

            IngredientsTab1.Visibility = Visibility.Hidden;
            IngredientsTab2.Visibility = Visibility.Visible;

            CookwareTab1.Visibility = Visibility.Visible;
            CookwareTab2.Visibility = Visibility.Hidden;

            StepsTab1.Visibility = Visibility.Visible;
            StepsTab2.Visibility = Visibility.Hidden;

        }

        private void CookwareTab1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            IngredientsListScroller.Visibility = Visibility.Hidden;
            CookwareListScroller.Visibility = Visibility.Visible; // Show cookware checklist, hide others
            RecipeStepsScroller.Visibility = Visibility.Hidden;

            IngredientsTab1.Visibility = Visibility.Visible;
            IngredientsTab2.Visibility = Visibility.Hidden;

            CookwareTab1.Visibility = Visibility.Hidden;
            CookwareTab2.Visibility = Visibility.Visible;

            StepsTab1.Visibility = Visibility.Visible;
            StepsTab2.Visibility = Visibility.Hidden;
        }

        private void StepsTab1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            IngredientsListScroller.Visibility = Visibility.Hidden;
            CookwareListScroller.Visibility = Visibility.Hidden;
            RecipeStepsScroller.Visibility = Visibility.Visible; //Show recipe steps scroller and hide others

            IngredientsTab1.Visibility = Visibility.Visible;
            IngredientsTab2.Visibility = Visibility.Hidden;

            CookwareTab1.Visibility = Visibility.Visible;
            CookwareTab2.Visibility = Visibility.Hidden;

            StepsTab1.Visibility = Visibility.Hidden;
            StepsTab2.Visibility = Visibility.Visible;
        }

        private void StartButton_RecipePage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!VerifyAllBoxesChecked())
            {
                ReminderBox.Visibility = Visibility.Visible;
            }
            else
            {
                // Update settings
                updateSettings();

                // Skip the recipe techniques page if setting #2 is enabled
                if (settingsEnabled[1] == '1')
                {
                    pageStack.Push(RecipeMainPage);
                    SkipToSteps();
                }
                else
                {
                    RecipeTechniques.Children.Clear(); //clear old techniques
                    BringFront(TechniquesForRecipePage, null);
                    foreach (string recipeTechnique in TechniqueList)
                    {
                        GlossaryEntry newTerm = new GlossaryEntry(recipeTechnique);
                        newTerm.MouseLeftButtonDown += OnTermClicked;
                        newTerm.MouseEnter += Pasta_MouseEnter;
                        newTerm.MouseLeave += Pasta_MouseLeave;
                        this.RecipeTechniques.Children.Add(newTerm);
                    }
                }
            }
        }

        // copy of lines around 760
        private void SkipToSteps()
        {
            currentStep = 1;
            UpdateSingleStepPage();
            PageTitle_Recipes1.Text = currentRecipeName;
            PageTitle_Recipes2.Text = currentRecipeName;
            BringFront(SingleStepPage1, null);
        }

        // When a recipe thumbnail is clicked
        private void OnThumbnailClicked(object sender, MouseButtonEventArgs e)
        {

            updateSettings();

            currentRecipe = RecipeMainPage;
            this.PageTitle_RecipeMain.Text = (sender as RecipeBlock).ImageText.Text;
            this.RecipeImage_Main.Source = (sender as RecipeBlock).ImageOfPhoto.Source;

            string recipeName = (sender as RecipeBlock).ImageText.Text;
            string recipeName1 = "Recipes\\" + recipeName.Replace(' ', '-') + ".txt";

            currentRecipeName = recipeName;

            ClearRecipe(); //reset recipe page 

            ReadRecipe(recipeName1); //parse the recipe file to find ingredients, cooktime, etc.

            UpdateIngredientsBoxes(); //update recipe page with ingredients checkboxes
            UpdateCookwareBoxes();
            UpdateStepsTab();
            UpdateDifficulty();
            UpdateCookTime();

            // If setting #3 is enabled, skip the main recipe page and directly go to the steps
            if (settingsEnabled[2] == '1')
            {
                pageStack.Push(RecipesPage);
                SkipToSteps();
            }
            else
            {
                BringFront(RecipeMainPage, null);
            }
        }

        /// <summary>
        /// Resets the recipe page so it can be refilled with the content from a new recipe.
        /// Clears content of lists associated with recipe page. Unchecks all boxes.
        /// </summary>
        private void ClearRecipe()
        {
            //Make sure all lists are cleared of previous recipes
            IngredientsList.Clear();
            CookwareList.Clear();
            StepsList.Clear();
            TechniqueList.Clear();
            totalTechniques = 0;

            //Clear Checkbox lists
            checkedBoxesIngredients.Clear();
            checkedBoxesCookware.Clear();
            AllCookwareBoxes.Clear();
            AllIngredientBoxes.Clear();

            //Uncheck Select All boxes
            AllIngredientsCheckbox.IsChecked = false;
            AllCookwareCheckbox.IsChecked = false;

            //Remove Ingredients/Cookware/Steps from grids
            IngredientsGrid.Children.RemoveRange(2, IngredientsGrid.Children.Count);
            CookwareGrid.Children.RemoveRange(2, CookwareGrid.Children.Count);
            RecipeStepsGrid.Children.Clear();

            //Reset Step Count
            currentStep = 0;
            totalSteps = 0;

            // --->
            // Check if the skip checklist enabled first
            // Clear only if it's disabled
            if (settingsEnabled[0] != '1')
            {
                //Reset Start Button
                StartButton4.Opacity = 0.5;
                //StartButton4.IsEnabled = false;
            }

            //Reset visible tab to ingredients
            IngredientsListScroller.Visibility = Visibility.Visible; //Show ingredients checklist, hide others
            CookwareListScroller.Visibility = Visibility.Hidden;
            RecipeStepsScroller.Visibility = Visibility.Hidden;

            IngredientsTab1.Visibility = Visibility.Hidden;
            IngredientsTab2.Visibility = Visibility.Visible;

            CookwareTab1.Visibility = Visibility.Visible;
            CookwareTab2.Visibility = Visibility.Hidden;

            StepsTab1.Visibility = Visibility.Visible;
            StepsTab2.Visibility = Visibility.Hidden;

            //Clear the techniques for the recipe
            RecipeTechniques.Children.Clear();
            TechniqueList.Clear();
        }

        private void ReadRecipe(string recipeName1)
        {

            string current = null;
            string[] recipeInstructions = System.IO.File.ReadAllLines(recipeName1);
            foreach (string line in recipeInstructions)
            {
                

                if (line == "")
                {
                    current = null;
                }

                if (current == "Ingredients")
                {
                    //Line is an ingredient, add to ingredients list
                    IngredientsList.Add(line);

                }

                else if (current == "Cookware")
                {
                    //line is a cookware, add to cookware list
                    CookwareList.Add(line);
                }

                else if (current == "Steps")
                {
                    // line is a step, save in steps list
                    StepsList.Add(line);
                    totalSteps++;
                }

                else if (current == "Techniques")
                {
                    // line is a step, save in steps list
                    TechniqueList.Add(line);
                    totalTechniques++;
                }

                if (line.Contains("Ingredients:")) //indicates start of ingredients list
                {
                    current = "Ingredients";
                }

                else if (line.Contains("Cookware:")) //indicates start of cookware list
                {
                    current = "Cookware";
                }

                else if (line.Contains("Steps:")) //indicates start of steps list
                {
                    current = "Steps";
                }

                else if (line.Contains("Techniques:")) //indicates start of steps list
                {
                    current = "Techniques";
                }

                else if (line.Contains("Difficulty:"))
                {
                    string[] temp;
                    temp = line.Split(':');
                    difficulty = temp[1];   //get number for difficulty of array
                }

                else if (line.Contains("Cooking Time:"))
                {
                    string[] temp;
                    temp = line.Split(':');
                    cookTime = temp[1];      //get cooking time
                }
            }
        }


        /// <summary>
        /// Creates a checkbox in IngredientsGrid for each ingredient stored
        /// in the IngredientsList
        /// </summary>
        private void UpdateIngredientsBoxes()
        {
            foreach (string ingredient in IngredientsList)
            {
                CheckBox cb = new CheckBox();
                cb.Content = ingredient;
                //set colour of text and text box
                Brush colour = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF59A47D"));
                cb.BorderBrush = colour;
                cb.Foreground = colour;
                cb.Checked += CheckBox_Checked_Ingredients; //subscribe new checkbox to Checked event
                cb.Unchecked += CheckBox_Unchecked_Ingredients; //subscribe new checkbox to Unchecked event
                IngredientsGrid.Children.Add(cb);
                AllIngredientBoxes.Add(cb);
            }
        }

        /// <summary>
        /// Creates a checkbox in CookwareGrid for each item stored
        /// in the CookwareList
        /// </summary>
        private void UpdateCookwareBoxes()
        {
            foreach (string cw in CookwareList)
            {
                CheckBox cb = new CheckBox();
                cb.Content = cw;
                Brush colour = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF59A47D"));
                cb.Foreground = colour;
                cb.BorderBrush = colour;
                cb.Checked += CheckBox_Checked_Cookware; //subscribe new checkbox to Checked event
                cb.Unchecked += CheckBox_Unchecked_Cookware; //subscribe new checkbox to Unchecked
                CookwareGrid.Children.Add(cb);
                AllCookwareBoxes.Add(cb);
            }
        }

        private void UpdateStepsTab()
        {
            foreach (string step in StepsList)
            {
                TextBlock s = new TextBlock();
                s.TextWrapping = TextWrapping.Wrap;
                s.Text = step + "\r\n";
                s.Foreground = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF59A47D"));
                RecipeStepsGrid.Children.Add(s);
            }
        }

        private void UpdateDifficulty()
        {
            RecipeDifficulty.Text = "Difficulty: " + difficulty;
            RecipeDifficulty.Foreground = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF59A47D"));
        }

        private void UpdateCookTime()
        {
            RecipeCooktime.Text = "Cooking Time: " + cookTime;
            RecipeCooktime.Foreground = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF59A47D"));
        }

        private void UpdateSingleStepPage()
        {
            InstructionsGrid.Children.Clear(); //clear previous step
            StepCounterText.Text = "Step " + currentStep + "/" + totalSteps;
            string[] temp1 = StepsList.ElementAt(currentStep - 1).Split(':');
            string step = temp1[1];

            //if the step contains a term
            if (step.Contains('*'))
            {
                string[] str = step.Split('*');
                int.TryParse(str[1], out techniqueForStep);
                TextBlock text1 = new TextBlock();
                TextBlock text2 = new TextBlock();
                TextBlock text3 = new TextBlock();
                SetStepFont(text1);
                SetStepFont(text2);
                SetStepFont(text3);
                text1.Text = str[0];
                InstructionsGrid.Children.Add(text1);
                text2.Text = str[2];
                text2.Foreground = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFE94D4E"));
                text2.MouseDown += TextBlock_MouseDown;
                InstructionsGrid.Children.Add(text2);
                if (str.Length == 4) //if there's more text after the term
                {
                    text3.Text = str[3];
                    InstructionsGrid.Children.Add(text3);
                }



            }
            else
            {
                TextBlock text = new TextBlock();
                SetStepFont(text);
                text.Text = step;
                InstructionsGrid.Children.Add(text);
            }



        }

        private void SetStepFont(TextBlock text)
        {
            text.TextWrapping = TextWrapping.Wrap;
            text.Foreground = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF59A47D"));
            text.FontSize = 24;
        }


        private void UpdateLastStepPage()
        {
            InstructionsGrid2.Children.Clear(); //clear previous step
            StepCounterText2.Text = "Step " + currentStep + "/" + totalSteps;
            string[] temp1 = StepsList.ElementAt(currentStep - 1).Split(':');
            string step = temp1[1];

            //if the step contains a term
            if (step.Contains('*'))
            {
                string[] str = step.Split('*');
                int.TryParse(str[1], out techniqueForStep);
                TextBlock text1 = new TextBlock();
                TextBlock text2 = new TextBlock();
                TextBlock text3 = new TextBlock();
                SetStepFont(text1);
                SetStepFont(text2);
                SetStepFont(text3);
                text1.Text = str[0];
                InstructionsGrid2.Children.Add(text1);
                text2.Text = str[2];
                text2.Foreground = new System.Windows.Media.SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFE94D4E"));
                text2.MouseDown += TextBlock_MouseDown;
                InstructionsGrid2.Children.Add(text2);
                if (str.Length == 4) //if there's more text after the term
                {
                    text3.Text = str[3];
                    InstructionsGrid2.Children.Add(text3);
                }
            }
            else
            {
                TextBlock text = new TextBlock();
                SetStepFont(text);
                text.Text = step;
                InstructionsGrid2.Children.Add(text);
            }

        }

        private void OnTermClicked(object sender, MouseButtonEventArgs e)
        {
            string nameTerm = (sender as GlossaryEntry).NameText.Text;
            string nameTerm1 = "Terms\\" + nameTerm.Replace(" ", "-") + ".txt";
            string nameTerm2 = "Terms\\" + nameTerm.Replace(" ", "-") + ".jpg";
            string[] termContents = System.IO.File.ReadAllLines(nameTerm1);
            string status = null;
            string termName = null;
            string termExplanation = null;
            foreach (string line in termContents)
            {
                if (line == "Term")
                {
                    status = "Term";
                }

                if (line == "Technique")
                {
                    status = "Technique";
                }

                if (line.Contains("Name:"))
                {
                    string[] nameContents = line.Split(':');
                    termName = nameContents[1];
                }

                if (line.Contains("Explanation:"))
                {
                    string[] explanationContents = line.Split(':');
                    termExplanation = explanationContents[1];
                }
            }

            Uri uri = new Uri(nameTerm2, UriKind.RelativeOrAbsolute);
            BitmapImage bitmap = new BitmapImage(uri);
            Image img = new Image();

            if (status == "Technique")
            {
                BringFront(ViewTechniquePage, null);
                this.TechniqueTitle.Text = termName;
                this.TechniqueImage.Source = bitmap;
            }

            if (status == "Term")
            {
                BringFront(ViewTermPage, null);
                this.TermTitle.Text = termName;
                this.TermImage.Source = bitmap;
                this.TermExplanationBox.Text = termExplanation;
            }
            currentTerm = termName;
        }

        private void BackButtonControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            pageStack.Pop();
            Grid previous = pageStack.Pop();
            BringFront(previous, MainFooterGrid);
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            Keyboard.Visibility = Visibility.Hidden;
        }



        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            Keyboard.Visibility = Visibility.Visible;
        }


        // Recipe Search
        private void SearchBoxRecipe_KeyUp(object sender, KeyEventArgs e)
        {
            // Get the current text from the searchbox
            string currentText = SearchBoxRecipes.Text.ToLower();

            for (int i = 0; i < RecipeDatabase.Count; i++)
            {
                // if not in the database, hide it     
                if (!RecipeDatabase[i].ToLower().StartsWith(currentText))
                {
                    this.RecipeGrid.Children[i].Visibility = Visibility.Collapsed;
                }
                // if it's in the database, show it 
                // -> when the search box is cleared, everything is shown again 
                else
                {
                    this.RecipeGrid.Children[i].Visibility = Visibility.Visible;

                }
            }

        }



        // Glossary Search
        private void SearchBoxGlossary_KeyUp(object sender, KeyEventArgs e)
        {
            // Get the current text from the searchbox
            string currentText = SearchBoxGlossary.Text.ToLower();

            for (int i = 0; i < GlossaryDatabase.Count; i++)
            {
                // if not in the database, hide it
                if (!GlossaryDatabase[i].ToLower().StartsWith(currentText))
                {
                    this.GlossaryGrid.Children[i].Visibility = Visibility.Collapsed;
                }
                // if it's in the database, show it 
                // -> when the search box is cleared, everything is shown again 
                else
                {
                    this.GlossaryGrid.Children[i].Visibility = Visibility.Visible;

                }
            }
        }


        private void GetNameOfTerm()
        {
            string nameTerm = TechniqueList.ElementAt(techniqueForStep - 1);
            string nameTerm1 = "Terms\\" + nameTerm.Replace(" ", "-") + ".txt";
            string nameTerm2 = "Terms\\" + nameTerm.Replace(" ", "-") + ".jpg";
            string[] termContents = System.IO.File.ReadAllLines(nameTerm1);
            string status = null;
            string termName = null;
            string termExplanation = null;
            foreach (string line in termContents)
            {
                if (line == "Term")
                {
                    status = "Term";
                }

                if (line == "Technique")
                {
                    status = "Technique";
                }

                if (line.Contains("Name:"))
                {
                    string[] nameContents = line.Split(':');
                    termName = nameContents[1];
                }

                if (line.Contains("Explanation:"))
                {
                    string[] explanationContents = line.Split(':');
                    termExplanation = explanationContents[1];
                }
            }

            Uri uri = new Uri(nameTerm2, UriKind.RelativeOrAbsolute);
            BitmapImage bitmap = new BitmapImage(uri);
            Image img = new Image();

            if (status == "Technique")
            {
                BringFront(ViewTechniquePage, null);
                this.TechniqueTitle.Text = termName;
                this.TechniqueImage.Source = bitmap;
            }

            if (status == "Term")
            {
                BringFront(ViewTermPage, null);
                this.TermTitle.Text = termName;
                this.TermImage.Source = bitmap;
            }
            currentTerm = termName;
        }

    }
}









